<!DOCTYPE html>
<html>
    <head>
        <title>Key Free - Trần Bá Đoan</title>
        <LINK REL="SHORTCUT ICON"  HREF="https://i.pinimg.com/originals/00/87/e6/0087e679caef91c64936bdb07c021f11.gif">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
<body>
<br>
<br>
<br>
<br>
<b>
<span style="font-family: Impact">
<h1><center><span style="font-size:50px">XIN CHÀO!!</span></center></h1>
</span>
</b>
<br>
<center>
<img src="https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/4843fc2a-40b0-47d2-8b76-30d467af7747/d6nqc8g-e5d9284d-2fb0-4a73-8a59-666126d27449.gif?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcLzQ4NDNmYzJhLTQwYjAtNDdkMi04Yjc2LTMwZDQ2N2FmNzc0N1wvZDZucWM4Zy1lNWQ5Mjg0ZC0yZmIwLTRhNzMtOGE1OS02NjYxMjZkMjc0NDkuZ2lmIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmZpbGUuZG93bmxvYWQiXX0.GNjpx-EqUPLi8tmFj_oPVXwDUxNiEzPOVRFJp7LTLTU" style=“width:250px;height:250px;”>
</center>
<br>
<br>
<span style="font-family: Comic Sans MS">
<span style="font-size:24px">
<?php
 
        $key = $_GET['key'];
        
        
        
       

 echo "<center>";
 echo "Cảm Ơn Bạn Đã Vượt Link Rút Gọn. Hãy Cùng Nhau Phát Triển Cộng Đồng Nhé"; echo "<br>";
 echo "Key 1 ngày đổi 1 lần"; echo "<br>";
 echo "API Key Ngày ";
 echo date('d/m/Y');
 echo " Là: "; echo "<br><b>";
 echo $key; echo "</b>";
 echo "<br>";
 echo "<br>";
 echo "<br>";
echo "</center>";
?>
</span>
</span>
<span style="font-family: Comic Sans MS">
<h><center><span style="font-size:20px">Copyright © Trần Bá Đoan 2022</span></center></h>
</span>
</body>
</html>